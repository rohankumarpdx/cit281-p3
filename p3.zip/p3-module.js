/*
    CIT 281 Project 3
    Name: Rohan Kumar
*/

//validDemonimation(coin): return true if the coin function parameter is a valid coin value (1, 5, 10, 25, 50 or 100)
function validDenomination(coin)
{
    let coinValues = [1, 5, 10, 25, 50, 100];
    let value = coinValues.indexOf(coin)
    if (value !== -1)
    {
        return true;
    }
    else
    {
        return false;
    }
}
console.log(validDenomination(75));

//valueFromCoinObject(obj): returns the calculated value of a single coin object from the obj function parameter
function valueFromCoinObject(obj)
{
    const {
        denom = 0,
        count = 0,
    } = obj;
    return denom * count;
}

//valueFromArray(arr): Iterates through an array of coin objects and returns the final calculated value of all coin objects
function valueFromArray(arr)
{
    return arr.reduce((accumulator, currentObj) => accumulator + valueFromCoinObject(obj), 0)
}

//coinCOunt(...coinage): Calls and returns the result of valueFromArray() function, which will be the value of all coin objects with the coinage array function parameter
function coinCount(...coinage)
{
    return valueFromArray(coinage);
}

module.exports =
{
    coinCount
}

